"""
비즈니스 서비스 모듈
"""

from .coin import get_coin_service

__all__ = ['get_coin_service']
