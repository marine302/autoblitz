# Safety module
